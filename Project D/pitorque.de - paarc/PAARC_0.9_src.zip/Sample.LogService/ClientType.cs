﻿
namespace Sample.LogService
{
    internal enum ClientType
    {
        WP7,
        PC
    }
}
